import { TextField } from "@material-ui/core";
import React from "react";
import { Control, Controller, RegisterOptions } from "react-hook-form";

interface Props {
  name: string;
  control: Control<any, object>;
  defaultValue: string;
  label: string;
  rules?: RegisterOptions,
  errorMessage?: string,
  isPassword?: boolean;
}

export const Input: React.FC<Props> = ({
  name,
  control,
  defaultValue,
  label,
  rules,
  errorMessage,
  isPassword,
}) => {
  return (
    <div>
      <Controller
        name={name}
        control={control}
        defaultValue={defaultValue}
        rules={rules}
        render={({ field }) => (
          <TextField
            {...field}
            error={errorMessage ? true : false}
            variant="outlined"
            label={label}
            className="w-full bg-white"
            color="primary"
            type={isPassword ? 'password' : 'text'}
            margin="dense"
          />
        )}
      />
      <span className="text-xs text-red-500"> { errorMessage }</span>
    </div>
  );
};
