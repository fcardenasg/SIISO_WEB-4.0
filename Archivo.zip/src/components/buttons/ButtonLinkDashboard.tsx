import { ArrowRight } from "@mui/icons-material";
import React from "react";

interface Props {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
}

export const ButtonLinkDashboard: React.FC<Props> = ({
  title,
  subtitle,
  icon,
}) => {
  return (
    <div className="bg-red-1 h-32 flex flex-row flex-1 rounded-xl shadow text-white font-montserrat font-semibold p-2 hover:bg-white hover:text-gray-700 hover:shadow-lg">
      <div className="flex flex-col flex-1 justify-end flex-wrap">
        <span className=" text-lg font-montserrat">{title}</span>
        <span className="text-xs font-montserrat font-semibold">
         {subtitle}
        </span>
      </div>
      <div className="flex flex-col justify-between items-center">
        { icon }
        <ArrowRight />
      </div>
    </div>
  );
};
