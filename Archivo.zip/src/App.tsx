import React from "react";
import "./App.css";
import RoutesApp from "./routes/routes";

function App() {
  return (
    <div className="App">
      <div className="bg-blue-50 sm:h-screen w-full">
        <RoutesApp />
      </div>
    </div>
  );
}

export default App;
