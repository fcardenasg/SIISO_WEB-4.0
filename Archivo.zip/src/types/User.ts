export type User = {
  name: string;
  lastname: string;
  user: string;
  uuid: string;
}