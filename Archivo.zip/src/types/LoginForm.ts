export type LoginForm = {
  user: string;
  password: string;
}