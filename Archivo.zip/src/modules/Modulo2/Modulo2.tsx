import React from "react";

export const Modulo2 = () => {
  return <div>Modulo 2</div>;
};
