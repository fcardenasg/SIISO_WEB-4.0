import { Switch } from "@material-ui/core";
import React from "react";
import { Controller, useForm } from "react-hook-form";
import { Input } from "../../components/input/Input";
import logo from "../../assets/img/logo.png";
import { ButtonPrimary } from "../../components/buttons/ButtonPrimary";

// Validacion
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { Link } from "react-router-dom";
import { ButtonOutline } from "../../components/buttons/ButtonOutline";

type RegisterForm = {
  Documento: string;
  Nombres: string;
  Celular: string;
  Email: string;
  Empresa: string;
  Vacunado: boolean;
  Arp: string;
  Eps: string;
};

const schemaValidation: Yup.SchemaOf<RegisterForm> = Yup.object({
  Documento: Yup.string()
    .required("Este campo es obligatorio")
    .min(3, "Este campo debe tener minimo 3 caracteres"),
  Nombres: Yup.string()
    .required("Este campo es obligatorio")
    .min(3, "Este campo debe tener minimo 3 caracteres"),
  Celular: Yup.string()
    .required("Este campo es obligatorio")
    .min(3, "Este campo debe tener minimo 3 caracteres"),
  Email: Yup.string()
    .required("Este campo es obligatorio")
    .email("El correo es invalido"),
  Empresa: Yup.string()
    .required("Este campo es obligatorio")
    .min(3, "Este campo debe tener minimo 3 caracteres"),
  Arp: Yup.string()
    .required("Este campo es obligatorio")
    .min(3, "Este campo debe tener minimo 3 caracteres"),
  Eps: Yup.string()
    .required("Este campo es obligatorio")
    .min(3, "Este campo debe tener minimo 3 caracteres"),
  Vacunado: Yup.boolean().required("Este campo es requerido"),
});

export const Register = () => {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<RegisterForm>({
    resolver: yupResolver(schemaValidation),
  });

  const handleClick = (data: RegisterForm) => {
    console.log(data);
  };

  return (
    <div className="p-5 sm:h-screen flex justify-center items-center">
      <div className="md:w-1/4">
        <div className="w-full flex justify-center">
          <img src={logo} alt="" className="h-28 w-28 my-6 object-center" />
        </div>
        <div className="w-full flex justify-center">
          <span className="text-gray-700 font-montserrat font-semibold uppercase text-2xl text-center">
            Registro de Visitante
          </span>
        </div>

        <div className="w-full border-b-2 border-red-1 my-4"></div>
        <Input
          control={control}
          name="Documento"
          errorMessage={errors?.Documento?.message}
          label="Documento"
          defaultValue=""
        />
        <Input
          control={control}
          name="Nombres"
          errorMessage={errors?.Nombres?.message}
          label="Nombres"
          defaultValue=""
        />
        <Input
          control={control}
          name="Celular"
          errorMessage={errors?.Celular?.message}
          label="Celular"
          defaultValue=""
        />
        <Input
          control={control}
          name="Email"
          errorMessage={errors?.Email?.message}
          label="Correo Electronico"
          defaultValue=""
        />
        <Input
          control={control}
          name="Empresa"
          errorMessage={errors?.Empresa?.message}
          label="Empresa"
          defaultValue=""
        />
        <Input
          control={control}
          name="Eps"
          errorMessage={errors?.Eps?.message}
          label="Eps"
          defaultValue=""
        />
        <Input
          control={control}
          name="Arp"
          errorMessage={errors?.Arp?.message}
          label="Arp"
          defaultValue=""
        />
        <div className="flex justify-between items-center bg-white border border-gray-300 rounded px-5 py-2 my-3">
          <span className="text-gray-700 text-lg font-montserrat">
            Vacunado contra Covid19
          </span>
          <Controller
            name="Vacunado"
            control={control}
            defaultValue={false}
            render={({ field }) => <Switch {...field} />}
          />
        </div>
        <ButtonPrimary onPress={handleSubmit(handleClick)} text="Registrarme" />
        <div className="h-3"></div>
        <Link to="/login">
          <ButtonOutline onPress={() => {}} text="Cancelar" />
        </Link>
      </div>
    </div>
  );
};
