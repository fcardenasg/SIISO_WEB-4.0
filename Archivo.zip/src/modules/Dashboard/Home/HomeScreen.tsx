import { AccessTimeFilled, AddBox, Person } from "@mui/icons-material";
import LocalHospitalIcon from "@mui/icons-material/LocalHospital";
import React from "react";
import { ButtonLinkDashboard } from "../../../components/buttons/ButtonLinkDashboard";
import { ButtonLinkLogin } from "../../../components/buttons/ButtonLinkLogin";
import colors from "../../../styles/colors";

export const HomeScreen = () => {
  return (
    <div className="flex flex-1 w-full flex-col gap-10">
      <h1 className="text-3xl text-gray-700 font-montserrat font-semibold">
        Inicio
      </h1>
      <div className="w-full flex justify-end">
        <button>
          <div className="flex flex-row gap-1 items-center">
            <AddBox sx={{ color: colors.primary }} />
            <span className="font-montserrat text-xs text-gray-700">Agregar más opciones</span>
          </div>
        </button>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 w-full pb-3">
        <ButtonLinkDashboard
          title="Personal"
          subtitle="Empleados, Contratistas y Visitantes"
          icon={<Person sx={{ fontSize: 40 }} />}
        />
        <ButtonLinkDashboard
          title="Atención"
          subtitle="Triage, Enfermería, Asesorias, EMO y Paraclinicos"
          icon={<LocalHospitalIcon sx={{ fontSize: 40 }} />}
        />
        <ButtonLinkDashboard
          title="Programación"
          subtitle="Triage, Enfermería, Asesorias, EMO y Paraclinicos"
          icon={<AccessTimeFilled sx={{ fontSize: 40 }} />}
        />
      </div>
      <hr />
      <span className="text-gray-700 font-montserrat font-semibold">
        ¿Qué deseas hacer?
      </span>
      <div className="grid grid-cols-2 gap-2 pb-3 lg:grid-cols-4">
        <ButtonLinkLogin url="">
          <span>Medicina Laboral</span>
        </ButtonLinkLogin>
        <ButtonLinkLogin url="">
          <span>Historico Medicina Lab.</span>
        </ButtonLinkLogin>
        <ButtonLinkLogin url="">
          <span>Ausentismo Laboral</span>
        </ButtonLinkLogin>
        <ButtonLinkLogin url="">
          <span>Reintegro</span>
        </ButtonLinkLogin>
        <ButtonLinkLogin url="">
          <span>Accidente de Trabajo</span>
        </ButtonLinkLogin>
        <ButtonLinkLogin url="">
          <span>Asesorias Medicas</span>
        </ButtonLinkLogin>
        <ButtonLinkLogin url="">
          <span>Pruebas de AD</span>
        </ButtonLinkLogin>
        <ButtonLinkLogin url="">
          <span>Framingham</span>
        </ButtonLinkLogin>
        <ButtonLinkLogin url="">
          <span>Ordenes</span>
        </ButtonLinkLogin>
        <ButtonLinkLogin url="">
          <span>Derechos de Petición</span>
        </ButtonLinkLogin>
      </div>
    </div>
  );
};
