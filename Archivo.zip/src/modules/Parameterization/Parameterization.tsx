import React from 'react'

export const Parameterization = () => {
  return (
    <div className="flex flex-1 w-full">
      <h1 className="text-3xl text-blue-1 font-montserrat font-semibold">Parametrización</h1>
    </div>
  )
}
