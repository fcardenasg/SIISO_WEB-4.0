import React from "react";

export const RecoverPasswordScreen = () => {
  return (
    <div>
      <h1>Recover Password</h1>
    </div>
  );
};
