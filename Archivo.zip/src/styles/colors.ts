const colors = {
  primary: "#E31937",
  blue: "#0072BC",
  yellow: "#FFF200"
}

export default colors;